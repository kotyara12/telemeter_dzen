## Root TLS certificates

## isrg_root_x1.pem
ISRG Root X1 certificate (used as root for MQTT, OTA and other servers) is valid until June 4, 2035 14:04:38

## api_telegram_org.pem
Telegram API certificate is valid until June 29, 2034 20:06:20

##digi_cert.pem
DigiCert Global Root CA is valid until November 10, 2031 3:00:00

##digi_cert_g2.pem
DigiCert Global Root G2 is valid until January 15, 2038 12:00:00